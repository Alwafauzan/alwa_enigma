package com.uhukuhuk.uhukuhukstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UhukuhukstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
